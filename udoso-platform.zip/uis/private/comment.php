<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.collapsible {
  color: white;
  cursor: pointer;
  width: auto;
  border: none;
  text-align: left;
  outline: none;
}

.active, .collapsible:hover {
  
}

.contentc {
  padding: 0 18px;
  display: none;
  overflow: hidden;
}
input[type=image]{
    width: 20px;
    height: 20px
}
textarea{
  border:1px solid #ccc;
  border-radius:4px;
  width:300px;
  height:30px;
  text-decoration:none;
  outline:none;
  resize:none;
  overflow:auto;
  color:#ccc;
  padding: 5px;
}
#cm{
  color:#555;
}
</style>
</head>
<body>
  <?php include '../config/connection.php';
  
  //$select_comm=mysqli_query($dbc,"select * from adv_tb");
  $select_comm=mysqli_query($dbc, "select * from comment inner JOIN adv_tb on adv_tb.a_id=comment.a_id order by adv_tb.a_id desc limit 5");

  //desktop-scorpion   pswd=Belachao
  ?>
    
    <?php while($roo=mysqli_fetch_array($select_comm)){?>
    
<a href="?cat=<?php echo $roo['description']; ?>"><input type="image" src="../assets/img/ment.png" title="comment" class="collapsible"></a>
<div class="contentc">
  
  <form action="?dashboard" method="post" class="collapsible">
  <textarea wrap="off" placeholder="comment here!" name="comment" id="comment"></textarea>
  <input type="image" src="../assets/img/sendi.png" title="send" name="send" class="collapsible">
</form>
<div class="list-comment">

  <p id="cm" class="collapsible">
  <?php echo $roo['comments'];?>
  </p>

</div>
</div>
<?php } ?>

<script>
    /*comment container*/
var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var contentc = this.nextElementSibling;
    if (contentc.style.display === "block") {
      contentc.style.display = "none";
    } else {
      contentc.style.display = "block";
    }
  });
}
</script>

</body>
</html>
