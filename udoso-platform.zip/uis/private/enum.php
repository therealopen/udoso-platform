
<?php
include '../config/connection.php';
include '../php/session.php';
//ALTER TABLE `student_tb` CHANGE `role` `role` ENUM('superControl','elimu','afya','mikopo','makazi','sheria','jinsia','michezo') CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL;
$query="select * from student_tb group by role";
$result=mysqli_query($dbc,$query);
while($row=mysqli_fetch_assoc($result)){
    $all_role .= "'".$row['role']."',";
   
}
echo $all_role .'<br>';
echo "'".$all_role."',";
if(isset($_POST['ministry'])){
    if(empty($_POST['role'])){
        $msg_r="<label>empty ministry!</label>";
    }else{
        $ministry_new = $_POST['role'];
        


$alter_=mysqli_query($dbc,"ALTER TABLE `student_tb` MODIFY COLUMN role ENUM($all_role'$ministry_new')");
if(!$alter_){
    $msg_r="<label>fail to add ministry!</label>";
}else{
    echo $msg_r="<label>successful added new ministry!</label>";
}    
}    }
?>


<div class="info">
    <div class="superControl-panel" style="margin:0px;padding: 5px;background: whitesmoke;">adding new ministry</div>
<table>
    <form action="" method="post">
        <tr>
            <td>new ministry</td>
        </tr>
        <tr>
            <td><?php echo $message ?></td>
        </tr>
        <tr>
            <td><input class="list-input" type="text" autofocus="" name="role" placeholder="ministry">
        
            </td>

        </tr>
        <tr><td><?php echo $msg_r; ?></td></tr>
        <tr>
            <td><input style="margin: 0px;" type="submit" value="submit" name="ministry">
            </td>
        </tr>
    </form>
</table>
</div>

<?php
       //date for adv gif popup
     //  include '../config/connection.php';
       $sql=("select accademic_year,fname,lname,mname,role,regno,email,password from student_tb where regno='$log_u' or email='$log_e' and password='$pa_s'");
       $result=mysqli_query($dbc,$sql);
       $row=mysqli_fetch_assoc($result);
$acyear=$row['accademic_year'];
       $date=$acyear;
       $now=date('Y-m-d');
ECHO $now.'<br>'.$date.'<br>';
       $diff=abs(strtotime($now) - strtotime($date));
       //$datediff=floor($diff / (24*60*60)); //for DAY
       //echo $datediff.'<br>';
       $year=floor($diff / (365*60*60*24)); //for year
       $month=floor(($diff - $year * 365 *24*60*60) /(30*60*60*24)); //for month
       $day=floor(($diff - $year *365*60*60*24 - $month*30*60*60*24)/ (24*60*60)); //for day

       echo $year.'for year, <br>'. $month.'month, <br>'.$day.' day<br>';
       echo $login_session_u;


?>
<br>
<?php
if($year >= 4){
    echo "your done here!<BR>";
}else{
    echo 4-$year.' years only remained!';
}
?>
