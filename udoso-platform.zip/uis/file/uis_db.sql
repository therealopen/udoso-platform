-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 01, 2021 at 08:30 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uis_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `adv_tb`
--

CREATE TABLE `adv_tb` (
  `a_id` int(11) NOT NULL,
  `description` varchar(100) NOT NULL,
  `file` varchar(255) NOT NULL,
  `adv` longtext NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adv_tb`
--

INSERT INTO `adv_tb` (`a_id`, `description`, `file`, `adv`, `date`, `status`, `id`) VALUES
(5, 'second year 2021/2022', '', 'A pharmacy system is a very dynamic, efficient and suitable information system that will enable a pharmacist to monitor his daily sales, stock, rate of demand of a variety of medicines easily and make adjustments whenever ', '2021-09-25 18:42:11', 'elimu', 22),
(6, 'third year 2023', '', 'A pharmacy system is a very dynamic, efficient and suitable information system that will enable a pharmacist to monitor his daily sales, stock, rate of demand of a variety of medicines easily and make adjustments whenever ', '2021-09-25 18:44:18', 'afya', 20),
(10, 'student loans 2022', '', 'would like to express our sincere and prior gratitude to all our supervisors both at the UCC college and the project site. We believe that you will guide us wisely and give us all the cooperation ', '2021-09-25 19:13:55', 'fedha', 26),
(14, 'elimu today', '', 'A Pharmacy System Is A Very Dynamic, Efficient And Suitable Information System That Will Enable A Pharmacist To Monitor His Daily Sales, Stock, Rate Of Demand Of A Variety Of Medicines Easily And Make Adjustments Whenever', '2021-09-26 07:57:12', 'elimu', 22),
(18, 'for all students 2021/2022', 'certificate.crt', 'would like to express our sincere and prior gratitude to all our supervisors both at the ucc college and the project site. we believe that you will guide us wisely and give us all the cooperation', '2021-09-28 19:19:32', 'mikopo', 25),
(20, 'today ipt', 'arrival note.pdf', 'WEB TECHNOLOGY: Task performed creating a relationship in a database relation. LINUX AND WINDOW SERVER ADMINISTRATION: installation of ubuntu configure static ip address and client also perfom some command like traceroute, hostname and other in order to manage networking deivices.', '2021-09-28 22:48:41', 'sheria', 21),
(43, 'family educated first', '', 'a pharmacy system is a very dynamic, efficient and suitable information system that will enable a pharmacist to monitor his daily sales, stock, rate of demand of a variety of medicines easily and make adjustments whenever', '2021-09-28 23:27:32', 'elimu', 22),
(44, 'limit your energy for future use!', '', 'a pharmacy system is a very dynamic, efficient and suitable information system that will enable a pharmacist to monitor his daily sales, stock, rate of demand of a variety of medicines easily and make adjustments whenever', '2021-09-28 23:28:06', 'elimu', 22);

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `comments` text NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `a_id` int(11) NOT NULL,
  `regno` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `comments`, `date`, `a_id`, `regno`) VALUES
(119, 'hey i am who i am engineering a live dodoma here you today is another day live or day choice is yours bigdig!', '2021-09-29 01:16:30', 5, 'T/UDOM/2017/00398'),
(136, 'hassan here my first comment and last living in life and suffer like a puppy is not your choice dear be good to other and copy whenever you can ! living in life and suffer like a puppy is not your choice dear be good to other and copy whenever you can !', '2021-09-29 02:41:26', 14, 'T/UDOM/2020/05540'),
(137, 'hassan here my first comment and last living in life and suffer like a puppy is not your choice dear be good to other and copy whenever you can ! living in life and suffer like a puppy is not your choice dear be good to other and copy whenever you can !', '2021-09-29 02:41:32', 14, 'T/UDOM/2020/05540'),
(138, 'hassan here my first comment and last living in life and suffer like a puppy is not your choice dear be good to other and copy whenever you can ! living in life and suffer like a puppy is not your choice dear be good to other and copy whenever you can !', '2021-09-29 02:41:42', 14, 'T/UDOM/2020/05540'),
(146, 'you cant move foward without! you cant move foward without! you cant move foward without! you cant move foward without! you cant move foward without! yes', '2021-09-30 12:21:39', 18, 'T/UDOM/2020/00448'),
(149, 'you cant move foward without! you cant move foward without! you cant move foward without! you cant move foward without! you cant move foward without! yes', '2021-09-30 12:26:31', 18, 'T/UDOM/2020/00392');

-- --------------------------------------------------------

--
-- Table structure for table `student_tb`
--

CREATE TABLE `student_tb` (
  `id` int(11) NOT NULL,
  `regno` varchar(30) NOT NULL,
  `fname` text NOT NULL,
  `mname` text NOT NULL,
  `lname` text NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `password` varchar(255) NOT NULL,
  `program` enum('BIS','MTA','SE','CS','TE','CE','IDIT','IS','HIS','DET') NOT NULL,
  `role` enum('student','admin','michezo','afya','elimu','fedha','makazi','mikopo','jinsia','sheria') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_tb`
--

INSERT INTO `student_tb` (`id`, `regno`, `fname`, `mname`, `lname`, `gender`, `email`, `phone`, `password`, `program`, `role`) VALUES
(14, 'T/UDOM/2020/00392', 'hassan', 'z', 'mnyawan', 'male', 'hassanmnyawami@hotmail.com', '0779285367', 'e2ecb7f5f9f596c45a037e689962d81acd5da3bb', 'SE', 'admin'),
(15, 'T/UDOM/2020/00448', 'ABIEL', 'N', 'YAKOBO', 'male', 'abidotnash@gmail.com', '0765044642', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'BIS', 'student'),
(16, 'T/UDOM/2020/00338', 'AYUB', 'M', 'DAUD', 'male', 'daudm@gmail.com', '0779285360', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'CE', 'michezo'),
(20, 'T/UDOM/2020/00343', 'emma', 'israel', 'musoma', 'male', 'emma@hotmail.com', '0779285369', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'IS', 'afya'),
(21, 'T/UDOM/2020/00293', 'IBRAHAM', 'SUMAI', 'SABAHA', 'male', 'ibraham@yahoo.com', '0787654324', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'HIS', 'sheria'),
(22, 'T/UDOM/2020/05540', 'aidary', 'ahmed', 'majura', 'male', 'aidarymajura@gmail.com', '0715871842', '7c222fb2927d828af22f592134e8932480637c0d', 'IDIT', 'elimu'),
(23, 'T/UDOM/2018/00392', 'HUSSEIN', 'Z', 'MNYAWAMI', 'male', 'husseinmnyawami02@yahoo.com', '0718369090', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'CS', 'makazi'),
(24, 'T/UDOM/2017/00398', 'ABUBAKARI', 'M', 'SAID', 'male', 'absaid@gmail.com', '0656173596', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'CS', 'jinsia'),
(25, 'T/UDOM/2018/00383', 'jaqckline', 'johson', 'kimalo', 'female', 'jaq.k@yahoo.com', '0718369092', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'IDIT', 'mikopo'),
(26, 'T/UDOM/2020/00492', 'loveness', 'biosion', 'lymo', 'female', 'biosion@hotmail.com', '0656173500', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'MTA', 'fedha');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adv_tb`
--
ALTER TABLE `adv_tb`
  ADD PRIMARY KEY (`a_id`),
  ADD KEY `adv_id` (`id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cmt` (`a_id`);

--
-- Indexes for table `student_tb`
--
ALTER TABLE `student_tb`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adv_tb`
--
ALTER TABLE `adv_tb`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;

--
-- AUTO_INCREMENT for table `student_tb`
--
ALTER TABLE `student_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `adv_tb`
--
ALTER TABLE `adv_tb`
  ADD CONSTRAINT `adv_id` FOREIGN KEY (`id`) REFERENCES `student_tb` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `cmt` FOREIGN KEY (`a_id`) REFERENCES `adv_tb` (`a_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
