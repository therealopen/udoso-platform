 <html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="assets/css/style.css">
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compactible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <title>UIS</title>
    </head>
    <body>
 <div id="footer"><center>udoso platform &copy;<?php echo date("Y")?></center></div>

</body>
</html>